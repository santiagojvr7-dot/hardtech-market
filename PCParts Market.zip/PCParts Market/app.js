
const products = [
  {
    id: 1,
    name: "AMD Ryzen 5 7600",
    category: "Procesadores",
    price: 899000,
    stock: 8,
    icon: "🧠",
    socket: "AM5"
  },
  {
    id: 2,
    name: "Intel Core i5-14600K",
    category: "Procesadores",
    price: 1299000,
    stock: 5,
    icon: "🧠",
    socket: "LGA1700"
  },
  {
    id: 3,
    name: "GeForce RTX 4060",
    category: "Tarjetas gráficas",
    price: 1599000,
    stock: 4,
    icon: "🎮"
  },
  {
    id: 4,
    name: "Radeon RX 7600",
    category: "Tarjetas gráficas",
    price: 1399000,
    stock: 3,
    icon: "🎮"
  },
  {
    id: 5,
    name: "Kingston Fury 16 GB DDR5",
    category: "Memoria RAM",
    price: 249000,
    stock: 12,
    icon: "💾"
  },
  {
    id: 6,
    name: "Corsair Vengeance 32 GB DDR5",
    category: "Memoria RAM",
    price: 429000,
    stock: 0,
    icon: "💾"
  },
  {
    id: 7,
    name: "Samsung 990 EVO 1 TB",
    category: "Almacenamiento",
    price: 389000,
    stock: 7,
    icon: "⚡"
  },
  {
    id: 8,
    name: "Kingston NV2 500 GB",
    category: "Almacenamiento",
    price: 189000,
    stock: 10,
    icon: "⚡"
  }
];

let selectedCategory = "Todos";
let cart = [];

const productGrid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const resultCount = document.getElementById("resultCount");

const money = value =>
  new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0
  }).format(value);

function renderProducts() {
  const search = searchInput.value.trim().toLowerCase();

  const filtered = products.filter(product => {
    const matchesCategory =
      selectedCategory === "Todos" ||
      product.category === selectedCategory;

    const matchesSearch =
      product.name.toLowerCase().includes(search) ||
      product.category.toLowerCase().includes(search);

    return matchesCategory && matchesSearch;
  });

  resultCount.textContent = `${filtered.length} productos`;

  if (filtered.length === 0) {
    productGrid.innerHTML =
      "<p>No encontramos productos con esa búsqueda.</p>";
    return;
  }

  productGrid.innerHTML = filtered.map(product => `
    <article class="product-card">
      <div class="product-art" aria-hidden="true">
        ${product.icon}
      </div>

      <div class="product-info">
        <p class="category">${product.category}</p>
        <h3>${product.name}</h3>
        <p class="price">${money(product.price)}</p>

        <p class="stock ${product.stock === 0 ? "out" : ""}">
          ${product.stock > 0
            ? `${product.stock} unidades disponibles`
            : "Agotado"}
        </p>

        <button
          class="primary-button"
          data-add="${product.id}"
          ${product.stock === 0 ? "disabled" : ""}
        >
          Agregar al carrito
        </button>
      </div>
    </article>
  `).join("");
}

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    selectedCategory = button.dataset.category;

    document.querySelectorAll(".filter").forEach(item => {
      item.classList.toggle("active", item === button);
    });

    renderProducts();
  });
});

searchInput.addEventListener("input", renderProducts);

productGrid.addEventListener("click", event => {
  const button = event.target.closest("[data-add]");
  if (!button) return;

  const product = products.find(
    item => item.id === Number(button.dataset.add)
  );

  if (!product || product.stock <= 0) return;

  const existing = cart.find(item => item.id === product.id);
  const quantityInCart = existing ? existing.quantity : 0;

  if (quantityInCart >= product.stock) {
    alert("No hay más unidades disponibles.");
    return;
  }

  if (existing) {
    existing.quantity++;
  } else {
    cart.push({ id: product.id, quantity: 1 });
  }

  renderCart();
});

function renderCart() {
  const cartCount = cart.reduce(
    (sum, item) => sum + item.quantity, 0
  );

  document.getElementById("cartCount").textContent = cartCount;

  document.getElementById("cartItems").innerHTML =
    cart.length
      ? cart.map(item => {
          const product = products.find(p => p.id === item.id);

          return `
            <div class="cart-row">
              <div>
                <strong>${product.name}</strong>
                <p>${item.quantity} × ${money(product.price)}</p>
              </div>
              <button data-remove="${product.id}">
                Quitar
              </button>
            </div>
          `;
        }).join("")
      : "<p>Tu carrito está vacío.</p>";

  const total = cart.reduce((sum, item) => {
    const product = products.find(p => p.id === item.id);
    return sum + product.price * item.quantity;
  }, 0);

  document.getElementById("cartTotal").textContent = money(total);
}

document.getElementById("cartItems").addEventListener("click", event => {
  const button = event.target.closest("[data-remove]");
  if (!button) return;

  cart = cart.filter(item => item.id !== Number(button.dataset.remove));
  renderCart();
});

const cartDialog = document.getElementById("cartDialog");

document.getElementById("cartButton").addEventListener("click", () => {
  cartDialog.showModal();
});

document.getElementById("closeCart").addEventListener("click", () => {
  cartDialog.close();
});

document.getElementById("checkoutButton").addEventListener("click", () => {
  if (cart.length === 0) {
    alert("Agrega productos antes de continuar.");
    return;
  }

  alert(
    "¡Tu carrito está listo! El pago y la creación de pedidos " +
    "se implementarán en la siguiente etapa."
  );
});

document.getElementById("checkCompatibility").addEventListener("click", () => {
  const cpu = document.getElementById("cpuSocket").value;
  const board = document.getElementById("boardSocket").value;
  const result = document.getElementById("compatResult");

  if (cpu === board) {
    result.textContent =
      "Coincidencia de socket: los componentes podrían ser compatibles. " +
      "Verifica el modelo de CPU, la BIOS y las especificaciones de la placa.";
    result.style.color = "#47d7a0";
  } else {
    result.textContent =
      "Incompatibilidad de socket: el procesador y la placa base " +
      "seleccionados no comparten el mismo socket.";
    result.style.color = "#ff9292";
  }
});

document.getElementById("sellButton").addEventListener("click", () => {
  alert(
    "El módulo de vendedores se desarrollará en una siguiente etapa."
  );
});

renderProducts();
renderCart();
