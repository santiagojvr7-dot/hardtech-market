
let productos = [];

async function cargarProductos() {
    try {
        const respuesta = await fetch("/api/productos");

        if (!respuesta.ok) {
            throw new Error("No se pudieron cargar los productos");
        }

        productos = await respuesta.json();

        mostrarProductos();
    } catch (error) {
        console.error("Error al cargar el catálogo:", error);
        listaProductos.textContent =
            "No fue posible cargar los productos. Intenta recargar la página.";
    }
}


// Elementos de la página
const listaProductos = document.getElementById("lista-productos");
const contadorCarrito = document.getElementById("contador-carrito");
const detalleCarrito = document.getElementById("detalle-carrito");
const totalCarrito = document.getElementById("total-carrito");

// Formato de precios en pesos colombianos
function formatearPrecio(precio) {
    return precio.toLocaleString("es-CO", {
        style: "currency",
        currency: "COP",
        maximumFractionDigits: 0
    });
}

// Cargar el carrito guardado
let carrito = [];

try {
    const carritoGuardado = JSON.parse(
        localStorage.getItem("hardtech-carrito")
    );

    if (Array.isArray(carritoGuardado)) {
        carrito = carritoGuardado.filter(
            producto =>
                producto &&
                typeof producto.nombre === "string" &&
                typeof producto.precio === "number"
        );
    }
} catch (error) {
    carrito = [];
}


function mostrarProductos() {
    listaProductos.innerHTML = "";

    productos.forEach((producto, indice) => {
        const tarjeta = document.createElement("article");
        tarjeta.classList.add("producto");

        tarjeta.innerHTML = `
            <div class="icono-producto">${producto.icono || "🖥️"}</div>
            <h3>${producto.nombre}</h3>
            <p>${producto.categoria}</p>
            <p><strong>${formatearPrecio(Number(producto.precio))}</strong></p>
            <p>Existencias: ${producto.existencias}</p>
            <button
                class="boton-agregar"
                type="button"
                data-indice="${indice}"
            >
                Agregar al carrito
            </button>
        `;

        listaProductos.appendChild(tarjeta);
    });
}


// Actualizar contador, lista, total y almacenamiento
function actualizarResumenCarrito() {
    contadorCarrito.textContent = carrito.length;

    detalleCarrito.innerHTML = "";

    carrito.forEach((producto, indice) => {
        const elemento = document.createElement("li");
        elemento.textContent =
            `${producto.nombre} - ${formatearPrecio(producto.precio)} `;

        const botonEliminar = document.createElement("button");
        botonEliminar.type = "button";
        botonEliminar.textContent = "Eliminar";
        botonEliminar.style.marginLeft = "10px";

        botonEliminar.addEventListener("click", () => {
            carrito.splice(indice, 1);
            actualizarResumenCarrito();
        });

        elemento.appendChild(botonEliminar);
        detalleCarrito.appendChild(elemento);
    });

    const total = carrito.reduce(
        (suma, producto) => suma + producto.precio,
        0
    );

    totalCarrito.textContent = formatearPrecio(total);

    localStorage.setItem(
        "hardtech-carrito",
        JSON.stringify(carrito)
    );
}

// Escuchar los clics en los botones
listaProductos.addEventListener("click", (evento) => {
    const boton = evento.target.closest(".boton-agregar");

    if (!boton) return;

    const indice = Number(boton.dataset.indice);
    const producto = productos[indice];

    if (!producto) return;

    carrito.push(producto);
    actualizarResumenCarrito();

    alert(`${producto.nombre} se agregó al carrito.`);
});

// Mostrar el carrito al abrir la página
actualizarResumenCarrito();


cargarProductos();